import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";
import { componentTagger } from "lovable-tagger";

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => ({
  server: {
    host: "::",
    port: 8080,
    // Dev-only proxy to avoid CORS when calling Yahoo Finance search endpoint.
    // The frontend calls: /api/yahoo/v1/finance/search?q=...&quotesCount=1
    // This proxy forwards to https://query2.finance.yahoo.com and sets a User-Agent header.
    proxy: {
      "/api/yahoo": {
        target: "https://query2.finance.yahoo.com",
        changeOrigin: true,
        secure: true,
        rewrite: (pathStr) => pathStr.replace(/^\/api\/yahoo/, ""),
        configure: (proxy) => {
          proxy.on("proxyReq", (proxyReq) => {
            // Some Yahoo endpoints may behave differently without a browser-like UA.
            proxyReq.setHeader("User-Agent", "Mozilla/5.0");
          });
        },
      },
    },
  },
  plugins: [react(), mode === "development" && componentTagger()].filter(Boolean),
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
}));
